package com.example.SPT.entity;

import java.time.LocalDate;
import java.time.LocalDateTime;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Data
@Getter
@Setter
@Builder
@NoArgsConstructor
@AllArgsConstructor
@Document(collection = "students")
public class Student {

    @Id
    private String id;

    private String studentId;

    // Personal Details
    private String firstName;
    private String lastName;
    private String email;
    private String mobile;
    private LocalDate dateOfBirth;
    private String gender;

    // Academic Details
    private String collegeName;
    private String degree;
    private String branch;
    private Integer passingYear;
    private Double cgpa;

    // Batch Information
    private String batchName;
    private String batchId;

    // Profile
    private String profileImage;

    // Account
    private String password;
    private Boolean active;

    // Selection Process
    private SelectionStatus selectionStatus;

    // Audit Fields
    private LocalDateTime createdAt;
    private LocalDateTime updatedAt;
}